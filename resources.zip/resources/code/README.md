# Final Project

Please refer to [Final Project - Instructions](https://docs.google.com/document/d/1WTIlXO1I2D_5muNTrKTUjtx6dUmHqb8MzeYgwu9oky4/edit?usp=sharing) for full instructions.

#Instructions for Running:

python main.py input-image-path output-image-path

python main.py images/source/apple.jpg

python main.py images/source/apple.jpg paintedApple.jpg


#Language
Python 2.7

#Lib
Numpy, 
Scipy, 
OpenCV

